import * as Common from '../common/common.js';
import * as Platform from '../platform/platform.js';
import * as ProtocolClient from '../protocol_client/protocol_client.js';
import type * as Protocol from '../../generated/protocol.js';
export interface RegistrationInfo {
    capabilities: number;
    autostart: boolean;
    early?: boolean;
}
declare const registeredModels: Map<new (arg1: Target) => SDKModel, RegistrationInfo>;
export declare class SDKModel extends Common.ObjectWrapper.ObjectWrapper {
    _target: Target;
    constructor(target: Target);
    target(): Target;
    /**
     * Override this method to perform tasks that are required to suspend the
     * model and that still need other models in an unsuspended state.
     */
    preSuspendModel(_reason?: string): Promise<void>;
    suspendModel(_reason?: string): Promise<void>;
    resumeModel(): Promise<void>;
    /**
     * Override this method to perform tasks that are required to after resuming
     * the model and that require all models already in an unsuspended state.
     */
    postResumeModel(): Promise<void>;
    dispose(): void;
    static register(modelClass: new (arg1: Target) => SDKModel, registrationInfo: RegistrationInfo): void;
    static get registeredModels(): typeof registeredModels;
}
export declare class Target extends ProtocolClient.InspectorBackend.TargetBase {
    _targetManager: TargetManager;
    _name: string;
    _inspectedURL: string;
    _inspectedURLName: string;
    _capabilitiesMask: number;
    _type: Type;
    _parentTarget: Target | null;
    _id: string;
    _modelByConstructor: Map<new (arg1: Target) => SDKModel, SDKModel>;
    _isSuspended: boolean;
    _targetInfo: Protocol.Target.TargetInfo | undefined;
    _creatingModels?: boolean;
    constructor(targetManager: TargetManager, id: string, name: string, type: Type, parentTarget: Target | null, sessionId: string, suspended: boolean, connection: ProtocolClient.InspectorBackend.Connection | null, targetInfo?: Protocol.Target.TargetInfo);
    createModels(required: Set<new (arg1: Target) => SDKModel>): void;
    id(): string;
    name(): string;
    type(): Type;
    markAsNodeJSForTest(): void;
    targetManager(): TargetManager;
    hasAllCapabilities(capabilitiesMask: number): boolean;
    decorateLabel(label: string): string;
    parentTarget(): Target | null;
    dispose(reason: string): void;
    model<T extends SDKModel>(modelClass: new (arg1: Target) => T): T | null;
    models(): Map<new (arg1: Target) => SDKModel, SDKModel>;
    inspectedURL(): string;
    setInspectedURL(inspectedURL: string): void;
    suspend(reason?: string): Promise<void>;
    resume(): Promise<void>;
    suspended(): boolean;
    updateTargetInfo(targetInfo: Protocol.Target.TargetInfo): void;
    targetInfo(): Protocol.Target.TargetInfo | undefined;
}
export declare enum Capability {
    Browser = 1,
    DOM = 2,
    JS = 4,
    Log = 8,
    Network = 16,
    Target = 32,
    ScreenCapture = 64,
    Tracing = 128,
    Emulation = 256,
    Security = 512,
    Input = 1024,
    Inspector = 2048,
    DeviceEmulation = 4096,
    Storage = 8192,
    ServiceWorker = 16384,
    Audits = 32768,
    WebAuthn = 65536,
    IO = 131072,
    None = 0
}
export declare enum Type {
    Frame = "frame",
    ServiceWorker = "service-worker",
    Worker = "worker",
    Node = "node",
    Browser = "browser"
}
export declare class TargetManager extends Common.ObjectWrapper.ObjectWrapper {
    _targets: Set<Target>;
    _observers: Set<Observer>;
    _modelListeners: Platform.MapUtilities.Multimap<string | symbol, {
        modelClass: new (arg1: Target) => SDKModel;
        thisObject: (Object | undefined);
        listener: (arg0: Common.EventTarget.EventTargetEvent) => void;
    }>;
    _modelObservers: Platform.MapUtilities.Multimap<new (arg1: Target) => SDKModel, SDKModelObserver<any>>;
    _isSuspended: boolean;
    private constructor();
    static instance({ forceNew }?: {
        forceNew: boolean;
    }): TargetManager;
    static removeInstance(): void;
    suspendAllTargets(reason?: string): Promise<void>;
    resumeAllTargets(): Promise<void>;
    allTargetsSuspended(): boolean;
    models<T extends SDKModel>(modelClass: new (arg1: Target) => T): T[];
    inspectedURL(): string;
    observeModels<T extends SDKModel>(modelClass: new (arg1: Target) => T, observer: SDKModelObserver<T>): void;
    unobserveModels<T extends SDKModel>(modelClass: new (arg1: Target) => SDKModel, observer: SDKModelObserver<T>): void;
    modelAdded(target: Target, modelClass: new (arg1: Target) => SDKModel, model: SDKModel): void;
    _modelRemoved(target: Target, modelClass: new (arg1: Target) => SDKModel, model: SDKModel): void;
    addModelListener(modelClass: new (arg1: Target) => SDKModel, eventType: string | symbol, listener: (arg0: Common.EventTarget.EventTargetEvent) => void, thisObject?: Object): void;
    removeModelListener(modelClass: new (arg1: Target) => SDKModel, eventType: string | symbol, listener: (arg0: Common.EventTarget.EventTargetEvent) => void, thisObject?: Object): void;
    observeTargets(targetObserver: Observer): void;
    unobserveTargets(targetObserver: Observer): void;
    createTarget(id: string, name: string, type: Type, parentTarget: Target | null, sessionId?: string, waitForDebuggerInPage?: boolean, connection?: ProtocolClient.InspectorBackend.Connection, targetInfo?: Protocol.Target.TargetInfo): Target;
    removeTarget(target: Target): void;
    targets(): Target[];
    targetById(id: string): Target | null;
    mainTarget(): Target | null;
}
export declare enum Events {
    AvailableTargetsChanged = "AvailableTargetsChanged",
    InspectedURLChanged = "InspectedURLChanged",
    NameChanged = "NameChanged",
    SuspendStateChanged = "SuspendStateChanged"
}
export declare class Observer {
    targetAdded(_target: Target): void;
    targetRemoved(_target: Target): void;
}
export declare class SDKModelObserver<T> {
    modelAdded(_model: T): void;
    modelRemoved(_model: T): void;
}
export {};
