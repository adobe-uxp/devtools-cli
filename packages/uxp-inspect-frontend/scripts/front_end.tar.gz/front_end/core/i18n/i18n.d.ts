import * as DevToolsLocale from './DevToolsLocale.js';
import * as i18n from './i18nImpl.js';
export { DevToolsLocale, i18n, };
