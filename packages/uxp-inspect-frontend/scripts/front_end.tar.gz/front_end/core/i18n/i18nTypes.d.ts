export interface SerializedMessage {
    string: string;
    values: Object;
}
