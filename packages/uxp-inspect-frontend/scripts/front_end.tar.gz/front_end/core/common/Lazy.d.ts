export declare function lazy<T>(producer: () => T): () => symbol | T;
