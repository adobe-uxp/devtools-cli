/**
 * Decodes Base64-encoded data from a string without performing any kind of checking.
 */
export declare function decode(input: string): ArrayBuffer;
