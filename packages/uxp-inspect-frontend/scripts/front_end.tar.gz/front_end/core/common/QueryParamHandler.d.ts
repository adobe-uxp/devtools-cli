/**
 * @interface
 */
export interface QueryParamHandler {
    handleQueryParam(value: string): void;
}
