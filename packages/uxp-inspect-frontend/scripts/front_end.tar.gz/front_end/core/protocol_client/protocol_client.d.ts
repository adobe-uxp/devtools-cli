import * as InspectorBackend from './InspectorBackend.js';
import * as NodeURL from './NodeURL.js';
export { InspectorBackend, NodeURL, };
