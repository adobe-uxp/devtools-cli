export declare class NodeURL {
    static patch(object: {
        url: string;
    }): void;
    static _isPlatformPath(fileSystemPath: string, isWindows: boolean): boolean;
}
