import '../../core/root/root-legacy.js';
export declare function startApplication(_appName: string): Promise<void>;
export declare function startWorker(appName: string): Promise<void>;
