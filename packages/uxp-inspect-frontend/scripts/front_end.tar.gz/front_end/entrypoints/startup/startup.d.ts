import * as RuntimeInstantiator from './RuntimeInstantiator.js';
export { RuntimeInstantiator, };
