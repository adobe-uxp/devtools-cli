import * as WasmParserWorker from './WasmParserWorker.js';
export { WasmParserWorker, };
