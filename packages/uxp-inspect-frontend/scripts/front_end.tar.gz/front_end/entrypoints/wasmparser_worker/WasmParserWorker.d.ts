export declare function dissambleWASM(params: {
    content: string;
}, postMessage: (arg0: any) => void): void;
